@include("layouts.header")
@include("layouts.nav")
@include("layouts.notification")

<!--top-Header-menu-->


<!--close-top-Header-menu-->


  
@yield('content')
 



@include("layouts.footer")